<?php

Class Cartera{

    private $clientes = [];
    private $fichero;


public function __construct($fichero){
    $this->fichero = $fichero;
    $this->loadData($fichero);
}

public function getClientes($num){
	return $this->clientes[$num];
}

public function setCliente($cliente,$num){
    $this->clientes[$num] = $cliente;
}

public function isVip($investment){
	$vip = "no";
	if($investment > 1000000){
		$vip = "<td class='vip'>";
	}else{
		$vip = "<td class='noVip'>";
	}
	return $vip;
}
public function loadData($fichero){
    $gestor = fopen($fichero, "r");
    while (($element = fgetcsv($gestor)) !== false){
        array_push(
            $this->clientes, new Empresa(...$element)
        );
    }
    fclose($gestor);
}

public function delete($id){
	$cont=0;
	foreach($this->clientes as $client){
		if($client->getId() == $id){
			array_splice($this->clientes, $cont , 1);
		}
		$cont++;
	}
	$this->persist();
}

public function persist(){
	$gestor = fopen('data.csv', "w");
	foreach($this->clientes as $cliente){
		fputcsv($gestor, [$cliente->getId(), $cliente->getCompany(), $cliente->getInvestment(), $cliente->getDate(), $cliente->getActive()]);
	}
	fclose($gestor);
}

public function edit($id){
for ($i=0; $i <count($this->clientes) ; $i++) { 
	$datos=$this->clientes[$i];
	if ($datos->getId() == $id){
		$id = $datos->getId();
		$company = $datos->getCompany();
		$investment = $datos->getInvestment();
		$date = $datos->getDate();
		$active = $datos->getActive();
		$array = [$id, $company, $investment, $date, $active];
	}
}
return $array;
}
public function update($datos){
	foreach ($this->clientes as $client){
		if ($client->getId() == $datos['id']){
			$client->setId($datos['id']);
			$client->setCompany($datos['company']);
			$client->setInvestment($datos['investment']);
			$client->setDate($datos['date']);
			$active = $datos['active'];
		}
	}
	$this->persist();
}
public function add($datos){
	$gestor = fopen('data.csv', "w");
	foreach($this->clientes as $cliente){
		fputcsv($gestor, [$cliente->getId(), $cliente->getCompany(), $cliente->getInvestment(), $cliente->getDate(), $cliente->getActive()]);
	}
	fputcsv($gestor, $datos);
	fclose($gestor);
}
public function drawList(){

    $tabla = "";
	for ($i=0; $i < count($this->clientes); $i++) { 
		$id = $this->clientes[$i]->getId();
		$company = $this->clientes[$i]->getCompany();
		$investment = $this->clientes[$i]->getInvestment();
		$date = $this->clientes[$i]->getDate();
		$active = $this->clientes[$i]->getActive();
		$tabla.="<tr>
			<td>$id</td>";
			$vip = $this->isVip($investment);
			$tabla.= "$vip  $company </td>"; 	
			$tabla.=" <td>$investment €</td>";
			$tabla.= "<td>$date</td>";
			if($active == "True"){
			$tabla .= "<td><img src='img05.gif'> </td>";
			}
			else{
				$tabla .= "<td><img src='img06.gif'> </td>";
			}
            $tabla .= "<td><a href='delete.php?id=" . $this->clientes[$i]->getId() . "'><img src='del_icon.png' width='25'></a></td>";
            $tabla .= "<td><a href='edit.php?id=" . $this->clientes[$i]->getId() . "'><img src='edit_icon.png' width = '25'> </td>";
            $tabla .= "<tr>";
	}
	return $tabla;

}
}
?>