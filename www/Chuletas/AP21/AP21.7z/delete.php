<?php

require_once "autoloader.php";

$deleteCartera = new Cartera('data.csv');
$deleteCartera->delete(isset($_GET['id']) ? $_GET['id'] : null);

header("location: index.php");

?>